/* LUCAS MARTIN TRESER
    DUINOBOT v2.4
    Programa para controlar los motores.
*/


void setup() {

}


void loop() {

  // Motor M0
  digitalWrite(5, LOW);
  digitalWrite(7, HIGH);
  analogWrite(6, 255); // Velocidad 0 a 255.

  // Motor M1
  digitalWrite(4, HIGH);
  digitalWrite(2, LOW);
  analogWrite(3, 60); // Velocidad 0 a 255.

}
